export const userMenu = [
  {
    name: "Inventory",
    path: "/",
    icon: "fa-solid fa-warehouse",
  },
  {
    name: "Donar",
    path: "/donar",
    icon: "fa-solid fa-hand-holding-medical",
  },
  {
    name: "Hospital",
    path: "/hospital",
    icon: "fa-solid fa-hospital",
  },
  {
    name: "Orgnaisation",
    path: "/orgnaisation",
    icon: "fa-sharp fa-solid fa-building-ngo",
  },
];
